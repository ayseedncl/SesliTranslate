package com.erkankuscudeneme.proje_tasarim;

import android.app.Application;
import android.media.MediaPlayer;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;

import android.net.NetworkInfo;
import android.net.Uri;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;

import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;


import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import pl.droidsonroids.gif.GifImageView;


public class GenelBilgi extends AppCompatActivity {
    List<String> slisteV;
    GifImageView gif_view;
    private TextView txt,txt2;
    private SpeechRecognizer sr;
    private Intent recognizerIntent;
    ListView listView;
ListAdapter adapter;
    Context context = this;
    boolean erkan = false;

    RelativeLayout rl_ilk,rl_iki;
    private VideoView video_oynatma;
    private MediaController mediaController;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.genel_bilgi);
        gif_view = findViewById(R.id.resim_gif);
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new SesTanima());
        video_oynatma=findViewById(R.id.videoview);

      listView=findViewById(R.id.listview);
        slisteV=new ArrayList<>();
        Field[] fields= R.raw.class.getFields();
        for (int i=0;i<fields.length;i++)
        {

            slisteV.add(fields[i].getName());
            Log.i("listem","listenin"+i+". elemanı"+fields[i].getName());

        }


        adapter= new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,slisteV);
        listView.setAdapter(adapter);

        rl_ilk=findViewById(R.id.rl_1);
        rl_iki=findViewById(R.id.rl_2);
        mediaController = new MediaController(GenelBilgi.this);


       // Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.);

      // video_oynatma.setVideoURI(uri);
        video_oynatma.setMediaController(mediaController);
        video_oynatma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gerissayfa= new Intent(getApplicationContext(),GenelBilgi.class);
                startActivity(gerissayfa);
            }
        });



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                rl_ilk.setVisibility(View.INVISIBLE);
                rl_iki.setVisibility(View.INVISIBLE);

                String filename=slisteV.get(i);
                Log.i("video","ismi   :"+filename);
                int resID = getResources().getIdentifier(slisteV.get(i), "raw", getPackageName());
                String filepalac="android.resource://" + getPackageName() +"/raw/"+filename;
                video_oynatma.setVideoURI(Uri.parse(filepalac));
                video_oynatma.setVisibility(View.VISIBLE);
                video_oynatma.start();
                Log.i("video","video oynattı:"+filename);
            }
        });



        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getClass().getPackage().getName());

        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr");

        //recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName());
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "şimdi söyle");

        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);



        if (baglantiKontrol()) {
            sr.setRecognitionListener(new SesTanima());
            sr.startListening(recognizerIntent);
        } else {
            Toast.makeText(context, "Lütfen internet baglantınızı kontrol edin", Toast.LENGTH_LONG).show();
            Intent gecis = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(gecis);
        }
    }


    public boolean baglantiKontrol() {
        Log.i("erkanxx","internet kontrol");

        ConnectivityManager baglanti = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo net = baglanti.getActiveNetworkInfo();

        if (net != null && net.isAvailable() && net.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    public class SesTanima implements RecognitionListener {
        @Override
        public void onBeginningOfSpeech() {

            Log.i("erkanxx", "onBeginning");
        }

        @Override
        public void onEndOfSpeech() {

            gif_view.setVisibility(View.INVISIBLE);
            Log.i("erkanxx", "onEnOf");


        }

        @Override
        public void onError(int error) {

            Log.e("erkanxx", "hata: " + error);
            gif_view.setVisibility(View.INVISIBLE);
            if (error == 6 || error == 2 || error == 7 || error == 8) {

                final TextView textView = (TextView) findViewById(R.id.txtyazi);
                textView.setText("lütfen tekrar söyleyin");
                textView.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            sr.startListening(recognizerIntent);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });

            }
        }

        @Override
        public void onResults(Bundle results) {
            final ArrayList lst = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            Log.i("erkanxx", "onResult1233");





            //   txt.setText("hahahahahahah");
            Log.i("erkanxx", ""+lst.get(0).toString());

            final TextView textView = (TextView) findViewById(R.id.txtyazi);
           final String txt=lst.get(0).toString().toLowerCase();

            textView.setText(txt);

            textView.post(new Runnable() {
                public void run() {
                    try {
                        Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                        Thread.sleep(5000L);
                        Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");

switch (txt){
    case "meyveler":rl_ilk.setVisibility(View.INVISIBLE);
                  rl_iki.setVisibility(View.INVISIBLE);
                  Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.meyveler);
        video_oynatma.setVideoURI(uri);

        video_oynatma.setVisibility(View.VISIBLE);
        video_oynatma.start();
        break;
    case "renkler":rl_ilk.setVisibility(View.INVISIBLE);
        rl_iki.setVisibility(View.INVISIBLE);
        Uri uri2 = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.renkler);
        video_oynatma.setVideoURI(uri2);
        video_oynatma.setVisibility(View.VISIBLE);
        video_oynatma.start();
        break;
        default:
            textView.setText(txt+"  adlı video veri tabanında yok");
            sr.startListening(recognizerIntent);
}




                      //
                    } catch (InterruptedException e) { finish(); }
                }
            });
        }

        /*
                        if(txt.trim().toString()=="dünya") {
                            rl_ilk.setVisibility(View.INVISIBLE);
                            rl_iki.setVisibility(View.INVISIBLE);
                            Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.dunya);
                            video_oynatma.setVideoURI(uri);

                            video_oynatma.setVisibility(View.VISIBLE);
                            video_oynatma.start();
                        }
                        else if(txt.trim().toString()=="bilgisayar"){
                            rl_ilk.setVisibility(View.INVISIBLE);
                            rl_iki.setVisibility(View.INVISIBLE);
                            Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.dunya);
                            video_oynatma.setVideoURI(uri);

                            video_oynatma.setVisibility(View.VISIBLE);
                            video_oynatma.start();
                        }
                        else if(txt.trim().toString()=="türkiye"){
                            rl_ilk.setVisibility(View.INVISIBLE);
                            rl_iki.setVisibility(View.INVISIBLE);
                            Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.turkiye);
                            video_oynatma.setVideoURI(uri);

                            video_oynatma.setVisibility(View.VISIBLE);
                            video_oynatma.start();
                        }
                        else
                        { textView.setText(txt+"adlı video veri tabaında yok");}
                        */
        @Override
        public void onPartialResults(Bundle bundle) {
            Log.i("erkanxx", "onPartaResults");

        }

        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.i("erkanxx","onReadyForSpeech");


            gif_view.setVisibility(View.VISIBLE);

        }


        @Override
        public void onRmsChanged(float v) {
            Log.i("erkanxx","onRmsChanged");

        }

        @Override
        public void onBufferReceived(byte[] buffer) {

            Log.i("erkanxx", "onbuffer");

        }


        @Override
        public void onEvent(int eventType, Bundle params) {

            Log.i("erkanxx", "onEvent");
        }

    }


}

