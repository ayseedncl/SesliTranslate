package com.erkankuscudeneme.proje_tasarim;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TestSayfa extends AppCompatActivity {

    //erişim berlerleyiciler
    /*
     * public
     * protected
     * private
     * static
     * final
     *
     * */
    static int soruSayisi;
    MediaPlayer mp;

    String[] kelmeIm;
    String[] kelmeTm;

    List<String> listIng = new ArrayList<>();
    List<String> listTurk = new ArrayList<>();





    //    String mySounds ={"sound1","sound2"};
//    int mp3Resource = getResources().getIdentifier(mySounds[0], "raw" , String packageName);
//    mp = MediaPlayer.create(this,mp3Resource );
//      mp.start();

    //  int sesler[] = {R.raw.anne, R.raw.father, R.raw.apple, R.raw.red, R.raw.yellow, R.raw.blue, R.raw.green, R.raw.purple};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_sayfa);


      /*  kelmeIm = getResources().getStringArray(R.array.kIng);
        kelmeTm = getResources().getStringArray(R.array.kTr);

        for (int i = 0; i < kelmeTm.length; i++) {


            listTurk.add(kelmeTm[i]);
            listIng.add(kelmeIm[i]);
        }*/

    }


    public void Tik(View v) {
        if (v.getId() == R.id.btn10) {
            soruSayisi = 10;
        } else if (v.getId() == R.id.btn15) {
            soruSayisi = 15;
        }else if (v.getId() == R.id.btn20) {
            soruSayisi = 20;

        } else if (v.getId() == R.id.btn25) {
            soruSayisi = 25;
        }

        Intent gecis = new Intent(getApplicationContext(), TestSoru.class);
        startActivity(gecis);
    }
}

