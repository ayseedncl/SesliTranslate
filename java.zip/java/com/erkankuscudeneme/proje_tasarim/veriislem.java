package com.erkankuscudeneme.proje_tasarim;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.List;

public class veriislem extends AppCompatActivity {
    Button btn,btn1,btn2;
    EditText edt1,edt2;
    ListView listView;
    LinearLayout linearLayout;
    public void init(){
        edt1=(EditText)findViewById(R.id.editText);
        edt2=(EditText)findViewById(R.id.editText2);
        btn=(Button)findViewById(R.id.button);
        btn1=(Button)findViewById(R.id.button2);
        btn2=(Button)findViewById(R.id.button3);
        listView=(ListView)findViewById(R.id.veriler);
        //linearLayout=(LinearLayout)findViewById(R.id.linear);

    }
    public void buton_click(){

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Veritabani veritabanı=new Veritabani(veriislem.this);
                veritabanı.veriEkle(edt1.getText().toString(),edt2.getText().toString());
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Veritabani veritabanı=new Veritabani(veriislem.this);
                List<String> vVeriler =veritabanı.veriListele();
                ArrayAdapter<String> adapter=new ArrayAdapter<String>(veriislem.this,android.R.layout.activity_list_item,android.R.id.text1,vVeriler);
                listView.setAdapter(adapter);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Veritabani veritabanı=new Veritabani(veriislem.this);
                veritabanı.veriSil(edt1.getText().toString());
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veriislem);
        init();
        buton_click();
    }
}
