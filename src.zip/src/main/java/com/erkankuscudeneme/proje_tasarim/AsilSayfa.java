package com.erkankuscudeneme.proje_tasarim;

import android.media.MediaPlayer;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;

import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import pl.droidsonroids.gif.GifImageView;


public class AsilSayfa extends AppCompatActivity implements TextToSpeech.OnInitListener {
    private TextToSpeech oku;
    List<String> sliste;
    MediaPlayer mediaPlayer;
    GifImageView gif_view;
    private TextView txt, txt_2, txt_3;
    private SpeechRecognizer sr;
    private Intent recognizerIntent;
    LinearLayout rl_asil;
    Context context = this;
    boolean erkan = false;
    String kontrolKelime;
    String[] kelmeI;
    String[] kelmeT;
    String[] tumKelimler;
    String[] kelimeIng;
    String[] kelimeTr;
    String[] kelimeTrS;
    String yandexKey = "trnsl.1.1.20181104T021622Z.d7c16ea22a2226cf.c8b25bd6e0f5846741607b3d4240ed9554f53e6e";

    int z=0;

   List<String> listIng = new ArrayList<>();
    List<String> listTurk = new ArrayList<>();
    List<String> listTurkS = new ArrayList<>();








/*
    int sesler[] = {R.raw.anne, R.raw.father, R.raw.apple, R.raw.red, R.raw.yellow, R.raw.blue, R.raw.green, R.raw.purple,
            R.raw.orange, R.raw.brown, R.raw.white, R.raw.black, R.raw.gray, R.raw.pink, R.raw.monday, R.raw.tuesday, R.raw.wednesday,
            R.raw.thursday, R.raw.friday, R.raw.saturday, R.raw.sunday, R.raw.january, R.raw.fabruary, R.raw.march,
            R.raw.april, R.raw.may, R.raw.jun, R.raw.july, R.raw.august, R.raw.september, R.raw.october, R.raw.november,
            R.raw.december, R.raw.spring, R.raw.summer, R.raw.autumn, R.raw.winter};
*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.asil_sayfa);

        TextView textView = (TextView) findViewById(R.id.txt_ses);
        TextView textView2 = (TextView) findViewById(R.id.txt_ses_2);

        Intent sesIntent = new Intent();
        sesIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(sesIntent, 44);

       //sonradan ekledim

        sliste=new ArrayList<>();
        Field[] fields= R.raw.class.getFields();
        for(int i=0;i<fields.length;i++)
        {

            sliste.add(fields[i].getName());
            Log.i("listem","listenin"+i+". elemanı"+fields[i].getName());

        }
        //sonradan ekledim



      //  tumKelimler = getResources().getStringArray(R.array.kelimelerim);
        kelimeIng = getResources().getStringArray(R.array.keliIng);
        kelimeTr = getResources().getStringArray(R.array.keliTR);
        kelimeTrS = getResources().getStringArray(R.array.keliTrS);
      for (int i=0;i< kelimeIng.length;i++)
      {
          listIng.add(kelimeIng[i]);
          listTurk.add(kelimeTr[i]);
          listTurkS.add(kelimeTrS[i]);
      }



       /* Log.i("listelerim","nerdeyim tum kelime altındayım ");
        for (int i = 0; i < tumKelimler.length; i++) {
            listTurk.add(tumKelimler[i].substring(0, tumKelimler[i].indexOf("-")));
            listIng.add(tumKelimler[i].split("-")[1]);
        }

        for (int i = 0; i < tumKelimler.length; i++) {
            int a =tumKelimler[i].indexOf("-")+1;
            int b =tumKelimler[i].indexOf("=");
            listIng.add(tumKelimler[i].substring(0, tumKelimler[i].indexOf("-")));

            listTurk.add(tumKelimler[i].substring(a,b));
         listTurkS.add(tumKelimler[i].split("=")[1]);
          Log.i("listelerim","ing  "+listIng.get(i).toString());
          Log.i("listelerim","tr  "+listTurk.get(i).toString());
          Log.i("listelerim","trs  "+listTurkS.get(i).toString());
            Log.i("listelerim","elaman sayisi"+listTurkS.size());

        }*/

        Log.i("erkanxx", "oncreate");
        rl_asil = findViewById(R.id.asil_rl);
        gif_view = findViewById(R.id.resim_gif);
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new SesTanima());
        txt = (TextView) findViewById(R.id.txt_ses);
        txt_2 = (TextView) findViewById(R.id.txt_ses_2);


        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getClass().getPackage().getName());

        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr");

        //recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName());
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "şimdi söyle");

        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);


        if (baglantiKontrol()) {
            sr.setRecognitionListener(new SesTanima());
            sr.startListening(recognizerIntent);
        } else {
            Toast.makeText(context, "Lütfen internet baglantınızı kontrol edin", Toast.LENGTH_LONG).show();
            Intent gecis = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(gecis);
        }
    }


    public boolean baglantiKontrol() {
        Log.i("erkanxx", "internet kontrol");

        ConnectivityManager baglanti = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo net = baglanti.getActiveNetworkInfo();

        if (net != null && net.isAvailable() && net.isConnected()) {
            return true;
        } else {
            return false;
        }
    }


    public class SesTanima implements RecognitionListener {
        @Override
        public void onBeginningOfSpeech() {

            Log.i("erkanxx", "onBeginning");
        }

        @Override
        public void onEndOfSpeech() {

            gif_view.setVisibility(View.INVISIBLE);
            Log.i("erkanxx", "onEnOf");


        }

        @Override
        public void onError(int error) {

            Log.e("erkanxx", "hata: " + error);
            if (error == 6 || error == 2 || error == 7 || error == 8) {
                erkan = false;
                sr.startListening(recognizerIntent);
            }

            try {
                Thread.sleep(4000);


            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }

        @Override
        public void onResults(Bundle results) {
            final ArrayList lst = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            Log.i("erkanxx", "onResult1233");


           /* MediaPlayer ceviri_ses = MediaPlayer.create(AsilSayfa.this, R.raw.anne);
            ceviri_ses.start();*/

            Log.i("erkanxx", "" + lst.get(0).toString());

            final TextView textView = (TextView) findViewById(R.id.txt_ses);
            final TextView textView2 = (TextView) findViewById(R.id.txt_ses_2);
            String[] txt = lst.get(0).toString().toLowerCase().split(" ");


            String kelimeKrslk;
            String trkKlSs;

            int index;
            if (listTurk.contains(txt[0].trim().toLowerCase())) {


                index = listTurk.indexOf(txt[0]);
                Log.i("kar", "o eleman" + listTurk.get(index));
                kelimeKrslk = listIng.get(index);
                Log.i("erkanxx", "" + kelimeKrslk.toString());
                textView.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.VISIBLE);
                textView2.setText(txt[0]);
                textView.setTextSize(100);
                textView.setText(kelimeKrslk);

                int k = sliste.indexOf(kelimeKrslk.toString());
                Log.i("deneme2", "k nın degeri" + k);

                if (k == -1) {
                    oku.setLanguage(Locale.ENGLISH);
                    oku.speak(kelimeKrslk, TextToSpeech.QUEUE_ADD, null);
                    oku.setSpeechRate((float) 0.75);
                    Log.i("deneme2", "içinde yok ve apiden okuyor" + k);


                } else if (k != -1) {
                    if (mediaPlayer != null) {
                        mediaPlayer.release();
                    }
                    int resID = getResources().getIdentifier(sliste.get(k), "raw", getPackageName());
                    Log.i("deneme2", "içinde var ve kendi veri tabanımdan okuyor" + k);

                    mediaPlayer = MediaPlayer.create(AsilSayfa.this, resID);
                    mediaPlayer.start();
                }




                textView.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(5000L);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            textView.setVisibility(View.INVISIBLE);
                            sr.startListening(recognizerIntent);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });
                //mother:mom
                /*if (kelimeKrslk.contains(":")) {
                    Log.i("kelimeI", kelimeKrslk);
                    String[] yeni = kelimeKrslk.toString().trim().split(":");

                    Random r = new Random();
                    int randm = r.nextInt(yeni.length);
                    String kelimeKrslkCoklu=yeni[randm];
                    textView.setText(kelimeKrslkCoklu);
                    Log.i("kelimeI", yeni[randm]);

                }*/


            } else if (listIng.contains(txt[0].trim().toLowerCase())) {

                index = listIng.indexOf(txt[0]);
                kelimeKrslk = listTurk.get(index);
                trkKlSs=listTurkS.get(index);
                textView.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.VISIBLE);
                textView2.setText(txt[0]);
                textView.setTextSize(100);
                textView.setText(kelimeKrslk);

                int k = sliste.indexOf(trkKlSs.toString());
                Log.i("deneme2", "k nın degeri" + k);

                if (k == -1) {
                    oku.setLanguage(new Locale("tr"));
                    oku.speak(kelimeKrslk, TextToSpeech.QUEUE_ADD, null);
                    oku.setSpeechRate((float) 0.75);
                    Log.i("deneme2", "içinde yok ve apiden okuyor" + k);


                } else if (k != -1) {
                    if (mediaPlayer != null) {
                        mediaPlayer.release();
                    }
                    int resID = getResources().getIdentifier(sliste.get(k), "raw", getPackageName());
                    Log.i("deneme2", "içinde var ve kendi veri tabanımdan okuyor" + k);

                    mediaPlayer = MediaPlayer.create(AsilSayfa.this, resID);
                    mediaPlayer.start();
                }


                textView.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(5000L);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            textView.setVisibility(View.INVISIBLE);
                            sr.startListening(recognizerIntent);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });


            } else if ((txt[0].equals("stop")) || (txt[0].equals("dur")) || (txt[0].equals("bitir"))) {
                textView.setTextSize(50);


                mediaPlayer = MediaPlayer.create(AsilSayfa.this, R.raw.baybay);
                mediaPlayer.start();


                /*oku.setLanguage(new Locale("tr"));

                oku.speak("Programdan çıkılıyor", TextToSpeech.QUEUE_ADD, null);
                oku.setSpeechRate((float) 0.75);*/

                textView.setVisibility(View.VISIBLE);
                textView.setText("Bye Bye...");
                textView.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(500);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            Intent gecis = new Intent(getApplicationContext(), MainActivity.class);
                            textView.setVisibility(View.INVISIBLE);
                            startActivity(gecis);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });

            } else {

                //burdan aşağısı sonradan yazıldı


                String cevirimtn = txt[0].toString();
                textView2.setText(cevirimtn);

                String query = null;
                try {
                    query = URLEncoder.encode(cevirimtn, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                String urlString = "https://translate.yandex.net/api/v1.5/tr.json/translate?key=" + yandexKey
                        + "&text=" + query + "&lang=" + "tr-en";
                new TranslatorBackgroundTask().execute(urlString);
            }


        }

        @Override
        public void onPartialResults(Bundle bundle) {
            Log.i("erkanxx", "onPartaResults");

        }

        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.i("erkanxx", "onReadyForSpeech");

            txt_2.setVisibility(View.INVISIBLE);
            gif_view.setVisibility(View.VISIBLE);

        }


        @Override
        public void onRmsChanged(float v) {
            Log.i("erkanxx", "onRmsChanged");

        }

        @Override
        public void onBufferReceived(byte[] buffer) {

            Log.i("erkanxx", "onbuffer");

        }


        @Override
        public void onEvent(int eventType, Bundle params) {

            Log.i("erkanxx", "onEvent");
        }

    }

    @Override
    protected void onPause() {

/*
        Intent gecis = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(gecis);*/
        super.onPause();
        /*Intent gecis = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(gecis);*/
        Log.i("deneme", "npausein iide");
    }


    //burdan aşağısını sonradan ekledim


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i("sesintent", "intentin on activity icinde");
        if (requestCode == 44) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                oku = new TextToSpeech(this, (TextToSpeech.OnInitListener) this);

            } else {
                Intent seshata = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                startActivity(seshata);
            }
        }
        //super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onInit(int i) {
        Log.i("sesintent", "intentin on init icinde");

    }

    class TranslatorBackgroundTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String urlString = params[0];
            StringBuilder jsonString = new StringBuilder();
            try {
                URL yandexUrl = new URL(urlString);
                HttpURLConnection httpURLConnection = (HttpURLConnection) yandexUrl.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    jsonString.append(line);
                }
                inputStream.close();
                bufferedReader.close();
                httpURLConnection.disconnect();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return jsonString.toString();
        }
        @Override
        protected void onPostExecute(String json) {
            JsonObject jsonObject=new JsonParser().parse(json).getAsJsonObject();
            String sonuc=jsonObject.get("text").getAsString();
            final TextView textView = (TextView) findViewById(R.id.txt_ses);
            final TextView textView2 = (TextView) findViewById(R.id.txt_ses_2);
            String snc=sonuc.toLowerCase().toString();
            Log.i("if", "z nin degeri"+z);

             Log.i("if","snc"+snc+"\n");
             Log.i("if","snc"+textView2.getText().toString()+"\n");


            if (snc.equals(textView2.getText().toString()))
            {   z++;
               if (z>1)
               {
                   sr.startListening(recognizerIntent);z=0;}
               else{
                   Log.i("if", "if yandex 1 icinde");

                String query = null;
                try {
                    query = URLEncoder.encode(snc, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                String urlString = "https://translate.yandex.net/api/v1.5/tr.json/translate?key=" + yandexKey
                        + "&text=" + query + "&lang=" + "en-tr";
                new TranslatorBackgroundTask().execute(urlString);
               }




            }
            else if (snc!=(textView2.getText().toString()))
            {
                if (z == 0)
                {
                    textView.setText(snc);
                    Log.i("if", "if yandex 2 else icinde");
                    textView.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.VISIBLE);
                    oku.setLanguage(Locale.ENGLISH);
                    oku.speak(snc, TextToSpeech.QUEUE_ADD, null);
                    oku.setSpeechRate((float) 0.75);
                    textView.post(new Runnable() {
                        public void run() {
                            try {
                                Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                                Thread.sleep(5000L);
                                Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                                textView.setVisibility(View.INVISIBLE);
                                sr.startListening(recognizerIntent);
                                z = 0;
                            } catch (InterruptedException e) {
                                finish();
                            }
                        }
                    });
                }
                else if (z == 1) {
                    textView.setText(snc);
                    Log.i("if", "if yandex 2 else icinde");
                    textView.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.VISIBLE);
                    oku.setLanguage(new Locale("tr_TR"));
                    oku.speak(snc, TextToSpeech.QUEUE_ADD, null);
                    oku.setSpeechRate((float) 0.75);
                    textView.post(new Runnable() {
                        public void run() {
                            try {
                                Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                                Thread.sleep(5000L);
                                Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                                textView.setVisibility(View.INVISIBLE);
                                sr.startListening(recognizerIntent);
                            } catch (InterruptedException e) {
                                finish();
                            }
                        }
                    });

                }

            }




















            }


        }
    }


