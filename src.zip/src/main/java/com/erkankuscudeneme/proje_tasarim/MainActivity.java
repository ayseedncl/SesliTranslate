package com.erkankuscudeneme.proje_tasarim;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    static  int control;
Button buton_gecis_ilk, buton_gecis_iki, buton_gecis_uc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buton_gecis_ilk=findViewById(R.id.buttonum_1);
        buton_gecis_iki=findViewById(R.id.buttonum_2);
        buton_gecis_uc=findViewById(R.id.buttonum_3);
     Button  buton4=findViewById(R.id.buttonum_4);
     Button  buton5=findViewById(R.id.buttonum_5);

        int MyVersion = Build.VERSION.SDK_INT;
        if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
            if (!checkIfAlreadyhavePermission()) {
                requestForSpecificPermission();
            }
        }
    }
    public void Tiklandi(View v){
if (baglantiKontrol())
{
    if (v.getId() == R.id.buttonum_1) {
        Intent gecis = new Intent(getApplicationContext(), AsilSayfa.class);
        startActivity(gecis);
    } else if (v.getId() == R.id.buttonum_2) {
        Intent gecis = new Intent(getApplicationContext(), CumleCevir.class);
        startActivity(gecis);
    } else if (v.getId() == R.id.buttonum_3) {
        Intent gecis = new Intent(getApplicationContext(), GenelBilgi.class);
        startActivity(gecis);
    } else if (v.getId() == R.id.buttonum_4) {
        control=1;
        Intent gecis = new Intent(getApplicationContext(), TestSayfa.class);
        startActivity(gecis);
    } else if (v.getId() == R.id.buttonum_5) {
        control=2;
        Intent gecis = new Intent(getApplicationContext(), TestSayfa.class);
        startActivity(gecis);
    }
    else if (v.getId() == R.id.buttonum_6) {
        Intent gecis = new Intent(getApplicationContext(), veriislem.class);
        startActivity(gecis);
    }
}
else {Toast.makeText(this, "İnternt Bağlantınızı Kontrol Edniz", Toast.LENGTH_SHORT).show();
                  Intent gecis=new Intent(getApplicationContext(),MainActivity.class);
                  startActivity(gecis);}





    }
     boolean checkIfAlreadyhavePermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }
    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 101);
    }
    public boolean baglantiKontrol() {
        Log.i("erkanxx","internet kontrol");

        ConnectivityManager baglanti = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo net = baglanti.getActiveNetworkInfo();

        if (net != null && net.isAvailable() && net.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

}
