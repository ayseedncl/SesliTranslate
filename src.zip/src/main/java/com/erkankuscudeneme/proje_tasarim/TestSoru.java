package com.erkankuscudeneme.proje_tasarim;

import android.annotation.SuppressLint;
import android.app.Application;
import android.media.MediaPlayer;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;

import android.net.NetworkInfo;
import android.net.Uri;
import android.opengl.Visibility;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;

import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;


import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;


import pl.droidsonroids.gif.GifImageView;


public class TestSoru extends AppCompatActivity implements TextToSpeech.OnInitListener{
    private TextToSpeech oku;
    List<String> sliste;
    MediaPlayer mediaPlayer;
    String[] tumKelimler;
    String[] kelimeIng;
    String[] kelimeTr;
    String[] kelimeTrS;
    TextView textView,txtsayi,txtD,txtY;
    int control;
    List<String> listTurk = new ArrayList<>();
    List<String> listIng = new ArrayList<>();
    List<String> listTurkS = new ArrayList<>();
    List<Integer> integerList = new ArrayList<>();
    List<String> slisteV;
    GifImageView gif_view, gif_cek;
    private TextView txt, txt2;
    private SpeechRecognizer sr;
    private Intent recognizerIntent;
    ListView listView;
    ListAdapter adapter;
    Context context = this;
    boolean erkan = false;
    int syc = 0,dogru=0,yanlis=0,a;
    TextView txtsncort;

    RelativeLayout rl_ilk, rl_iki;
    private VideoView video_oynatma;
    private MediaController mediaController;
    Random r = new Random();
    String b = "";
    int tstTur = MainActivity.control;
    ImageView dgrresim, dgrresim2, ynlsresim, ynlsresim2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_soru);

        final TextView textView5 = findViewById(R.id.textView5);
        TextView txtcevap = (TextView) findViewById(R.id.textView2);
        dgrresim = findViewById(R.id.imageView);
        txtD=findViewById(R.id.txtsayiD);
        txtY=findViewById(R.id.txtsayiY);

        ynlsresim = findViewById(R.id.imageView3);
        gif_view = findViewById(R.id.resim_gif);
        gif_view.setVisibility(View.INVISIBLE);
        txtsayi=findViewById(R.id.txtsayi);
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new SesTanima());
       // tumKelimler = getResources().getStringArray(R.array.kelimelerim);
        TextView txtsncort=findViewById(R.id.txtsnc1);

        kelimeIng = getResources().getStringArray(R.array.keliIng);
        kelimeTr = getResources().getStringArray(R.array.keliTR);
        kelimeTrS = getResources().getStringArray(R.array.keliTrS);
        for (int i=0;i< kelimeIng.length;i++)
        {
            listIng.add(kelimeIng[i]);
            listTurk.add(kelimeTr[i]);
            listTurkS.add(kelimeTrS[i]);
        }















       /* for (int i = 0; i < tumKelimler.length; i++) {
            int a =tumKelimler[i].indexOf("-")+1;
            int b =tumKelimler[i].indexOf("=");
            listIng.add(tumKelimler[i].substring(0, tumKelimler[i].indexOf("-")));

            listTurk.add(tumKelimler[i].substring(a,b));
            listTurkS.add(tumKelimler[i].split("=")[1]);
            Log.i("listelerim","ing  "+listIng.get(i).toString());
            Log.i("listelerim","tr  "+listTurk.get(i).toString());
            Log.i("listelerim","trs  "+listTurkS.get(i).toString());
            Log.i("listelerim","elaman sayisi"+listTurkS.size());

        }*/

        while (integerList.size() < TestSayfa.soruSayisi) {

            int sayi = r.nextInt(50);
            if (!integerList.contains(sayi)) {
                integerList.add(sayi);
            }

        }
        Intent sesIntent = new Intent();
        sesIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(sesIntent, 44);
        sliste=new ArrayList<>();
        Field[] fields= R.raw.class.getFields();
        for(int i=0;i<fields.length;i++)
        {

            sliste.add(fields[i].getName());
            Log.i("listem","listenin"+i+". elemanı"+fields[i].getName());

        }

        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getClass().getPackage().getName());

        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr");

        //recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName());
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "şimdi söyle");

        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);


        Log.i("erkanxx", "b nin degeri" + b);

         baglanti();

    }


    public void baglanti(){

        if (baglantiKontrol()) {

            soruSor(syc);


        }



        else {
            Toast.makeText(context, "Lütfen internet baglantınızı kontrol edin", Toast.LENGTH_LONG).show();
            Intent gecis = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(gecis);
        }



    }


















    public boolean baglantiKontrol() {
        Log.i("erkanxx", "internet kontrol");

        ConnectivityManager baglanti = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo net = baglanti.getActiveNetworkInfo();

        if (net != null && net.isAvailable() && net.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    public class SesTanima implements RecognitionListener {
        @Override
        public void onBeginningOfSpeech() {

            Log.i("erkanxx", "onBeginning");
        }

        @Override
        public void onEndOfSpeech() {

            gif_view.setVisibility(View.INVISIBLE);
            Log.i("erkanxx", "onEnOf");


        }

        @Override
        public void onError(int error) {

            Log.e("erkanxx", "hata: " + error);
            gif_view.setVisibility(View.INVISIBLE);
            if (error == 6 || error == 2 || error == 7 || error == 8) {

                final TextView txtcevap = (TextView) findViewById(R.id.textView2);
                txtcevap.setVisibility(View.VISIBLE);
                txtcevap.setText("lütfen tekrar söyleyin");
                txtcevap.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            sr.startListening(recognizerIntent);
                            txtcevap.setVisibility(View.INVISIBLE);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });

            }
        }

        @SuppressLint("ResourceAsColor")
        @Override
        public void onResults(Bundle results) {
            final ArrayList lst = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            Log.i("erkanxx", "onResult1233");


           /* MediaPlayer ceviri_ses = MediaPlayer.create(AsilSayfa.this, R.raw.anne);
            ceviri_ses.start();*/

            Log.i("erkanxx", "" + lst.get(0).toString());


            final TextView textView5 = (TextView) findViewById(R.id.textView5);
            final TextView txtcevap = (TextView) findViewById(R.id.textView2);
            String[] txt = lst.get(0).toString().toLowerCase().split(" ");

            String cevap = txt[0].toString();
            txtcevap.setText(cevap);
            txtcevap.setVisibility(View.VISIBLE);
            if ((cevap.equals("stop")) || (cevap.equals("dur")) || (cevap.equals("bitir")))
            {
                mediaPlayer = MediaPlayer.create(TestSoru.this, R.raw.baybay);
                mediaPlayer.start();
                textView5.setVisibility(View.VISIBLE);
                textView5.setText("Bye Bye...");
                textView5.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            Intent gecis = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(gecis);
                        }
                        catch (InterruptedException e)
                        {
                            finish();
                        }
                    }
                });



            }
            else if (cevap.equals(b)) {
                dgrresim.setVisibility(View.VISIBLE);
                dogru++;
                final TextView txtsnc = (TextView) findViewById(R.id.txtsnc1);

                txtsnc.setVisibility(View.VISIBLE);
                txtsnc.setText("Doğru");
                txtsnc.setTextColor(R.color.lightgreen);
                mediaPlayer = MediaPlayer.create(TestSoru.this, R.raw.dogru);
                mediaPlayer.start();
                txtcevap.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            baglanti();
                            txtcevap.setVisibility(View.INVISIBLE);
                            dgrresim.setVisibility(View.INVISIBLE);
                            txtsnc.setVisibility(View.INVISIBLE);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });

            } else if (cevap != b) {
                ynlsresim.setVisibility(View.VISIBLE);
                yanlis++;
                final TextView txtsnc = (TextView) findViewById(R.id.txtsnc1);
                txtsnc.setTextColor(R.color.red);
                txtsnc.setVisibility(View.VISIBLE);
                mediaPlayer = MediaPlayer.create(TestSoru.this, R.raw.yanlis);
                mediaPlayer.start();
                txtsnc.setText("Yanlış ("+b.toString()+")");
                txtsnc.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            baglanti();
                            txtcevap.setVisibility(View.INVISIBLE);
                            ynlsresim.setVisibility(View.INVISIBLE);
                            txtsnc.setVisibility(View.INVISIBLE);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });

            }



        }

        @Override
        public void onPartialResults(Bundle bundle) {
            Log.i("erkanxx", "onPartaResults");

        }

        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.i("erkanxx", "onReadyForSpeech");


            gif_view.setVisibility(View.VISIBLE);

        }


        @Override
        public void onRmsChanged(float v) {
            Log.i("erkanxx", "onRmsChanged");

        }

        @Override
        public void onBufferReceived(byte[] buffer) {

            Log.i("erkanxx", "onbuffer");

        }


        @Override
        public void onEvent(int eventType, Bundle params) {

            Log.i("erkanxx", "onEvent");
        }

    }

    public void soruSor(int i) {
        Log.i("erkanxx", "sorusayacta" + syc);
        a=syc+1;

            txtD.setText("Doğru Sayısı: "+dogru);
            txtY.setText("Yanlış Sayısı: "+yanlis);
        if (tstTur == 1) {

             if (syc < integerList.size()) {

                txtsayi.setText(""+a+". Soru");
                Log.i("erkanxx", "while a girdi");
                int soruSayi = integerList.get(i);
                String soru = listIng.get(soruSayi).toString();

               //sonradan yazıldı 12/12/2018
                int k = sliste.indexOf(soru.toString());
                Log.i("deneme2", "k nın degeri" + k);

                if (k == -1) {
                    //oku.setLanguage(Locale.ENGLISH);
                   // oku.speak(soru , TextToSpeech.QUEUE_ADD, null);
                   // oku.setSpeechRate((float) 0.75);
                    Log.i("deneme2", "içinde yok ve apiden okuyor" + k);


                } else if (k != -1) {
                    if (mediaPlayer != null) {
                        mediaPlayer.release();
                    }
                    int resID = getResources().getIdentifier(sliste.get(k), "raw", getPackageName());
                    Log.i("deneme2", "içinde var ve kendi veri tabanımdan okuyor" + k);

                    mediaPlayer = MediaPlayer.create(TestSoru.this, resID);
                    mediaPlayer.start();
                }



                Log.i("erkanxx", "soru" + soru);
                b = listTurk.get(soruSayi);
                Log.i("erkanxx", "soru" + b);

                final TextView textView5 = (TextView) findViewById(R.id.textView5);
                textView5.setText(soru);
                textView5.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            sr.startListening(recognizerIntent);
                            syc++;
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });


            }
            else

            {       final TextView textView5 = (TextView) findViewById(R.id.textView5);

               /* Log.i("erte", "elseye girdi sayac" + syc);
                final TextView textView5 = (TextView) findViewById(R.id.textView5);
                textView5.setText(  "test bitti");*/

                double ort=dogru/integerList.size();
                Log.d("testsonu", "ortaşaöa "+ort);
                if ((ort>0)&&(ort<=0.4)){
                    textView5.setText(  "daha çok çalışman lazım");
                }
                else if((ort>=0.5)&&(ort<=0.7))
            {  textView5.setText(  "biraz daha çalışmam lazım");
            }
                else if((ort>=0.8)&&(ort<=0.9))
                {  textView5.setText(  "çok iyi");
                }
                else if (ort==1)
                {  textView5.setText(  "mükemmel");
                }



                textView5.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Intent gecis = new Intent(getApplicationContext(), TestSayfa.class);
                            startActivity(gecis);
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });


            }



        }
        else if (tstTur == 2) {


            if (syc < integerList.size()) {
                txtsayi.setText(""+a+". Soru");

                Log.i("erkanxx", "while a girdi");
                int soruSayi = integerList.get(i);
                String soru = listTurk.get(soruSayi).toString();
                String soruTrS=listTurkS.get(soruSayi).toString();
                Log.i("erkanxx", "soru" + soru);
                b = listIng.get(soruSayi);
                Log.i("erkanxx", "soru" + b);

                //sonradan yazıldı 12/12/2018
                int k = sliste.indexOf(soruTrS.toString());
                Log.i("deneme2", "k nın degeri" + k);

                if (k == -1) {
                   // oku.setLanguage(new Locale("tr_TR"));
                  //  oku.speak(soru, TextToSpeech.QUEUE_ADD, null);
                  //  oku.setSpeechRate((float) 0.75);
                    Log.i("deneme2", "k nın degeri" + k);


                } else if (k != -1) {
                    if (mediaPlayer != null) {
                        mediaPlayer.release();
                    }
                    int resID = getResources().getIdentifier(sliste.get(k), "raw", getPackageName());
                    Log.i("deneme2", "içinde var ve kendi veri tabanımdan okuyor" + k);

                    mediaPlayer = MediaPlayer.create(TestSoru.this, resID);
                    mediaPlayer.start();
                }




                final TextView textView5 = (TextView) findViewById(R.id.textView5);
                textView5.setText(soru);

                textView5.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " now awake");
                            sr.startListening(recognizerIntent);
                            syc++;
                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });






            }
            else
            {


                final TextView textView5 = (TextView) findViewById(R.id.textView5);
                textView5.setText(  "sınav bitti");
                textView5.post(new Runnable() {
                    public void run() {
                        try {
                            Log.d("Sleeper", "Thread " + Thread.currentThread() + " going to sleep...");
                            Thread.sleep(2000);
                            Intent gecis = new Intent(getApplicationContext(), TestSayfa.class);
                            gecis.setFlags((Intent.FLAG_ACTIVITY_NO_HISTORY));
                            startActivity(gecis);

                        } catch (InterruptedException e) {
                            finish();
                        }
                    }
                });



                }
            }


        }

//sonradan ekledim
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i("sesintent", "intentin on activity icinde");
        if (requestCode == 44) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                oku = new TextToSpeech(this, (TextToSpeech.OnInitListener) this);

            } else {
                Intent seshata = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                startActivity(seshata);
            }
        }
        //super.onActivityResult(requestCode, resultCode, data);
    }
    @Override
    public void onInit(int i) {
        Log.i("sesintent", "intentin on init icinde");

    }

    @Override
    public void onBackPressed() {

        finish();

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }
}


